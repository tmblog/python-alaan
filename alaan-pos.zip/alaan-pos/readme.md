1. requires reservation prints
2. set environment
3. ability to change menu on cart
4. on saved cart click show active carts with count of items - created date and type as well as ability to delete this cart. group by type?
