import sqlite3
from flask import jsonify

def get_database_connection():
    try:
        # Connect to the SQLite database
        conn = sqlite3.connect('pos_database.db')  # Update with your database path
        cursor = conn.cursor()
        return conn, cursor
    except Exception as e:
        raise Exception(f"Error connecting to the database: {str(e)}")

def create_pos_database():
    try:
        # Connect to the SQLite database or create it if it doesn't exist
        conn, cursor = get_database_connection()

        # Create the 'category' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS category (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_name TEXT,
                category_order INTEGER
            )
        ''')

        # Create the 'products' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER,
                product_name TEXT,
                in_price REAL,
                out_price REAL,
                cpn INTEGER,
                FOREIGN KEY (category_id) REFERENCES category (category_id)
            )
        ''')

        # Create the 'options' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS options (
                option_id INTEGER PRIMARY KEY AUTOINCREMENT,
                option_name TEXT,
                option_order INTEGER,
                option_type TEXT,
                required INTEGER
            )
        ''')

        # Create the 'option_items' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS option_items (
                option_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                option_id INTEGER,
                option_item_name TEXT,
                option_item_in_price REAL DEFAULT 0,
                option_item_out_price REAL DEFAULT 0,
                FOREIGN KEY (option_id) REFERENCES options (option_id)
            )
        ''')

        # Create the 'product_options' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS product_options (
                product_id INTEGER,
                option_id INTEGER,
                FOREIGN KEY (product_id) REFERENCES products (product_id),
                FOREIGN KEY (option_id) REFERENCES options (option_id)
            )
        ''')

        # Create the cart table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cart (
                cart_id INTEGER PRIMARY KEY,
                order_type TEXT, -- Delivery, Collection, etc.
                order_menu INTEGER, -- 1 or 0 for takeaway or delivery menu
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                overall_note TEXT, -- Overall note for the entire order
                customer_id INTEGER
            )
        ''')

        # Create the cart_item table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cart_item (
                cart_item_id INTEGER PRIMARY KEY,
                cart_id INTEGER,
                product_id INTEGER,
                product_name TEXT,
                price DECIMAL(10, 2), -- Adjust precision and scale as needed
                quantity INTEGER,
                options JSON, -- Use TEXT data type for JSON data
                product_note TEXT -- Note specific to a product
            )
        ''')

        # Create the 'customers' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                customer_id INTEGER PRIMARY KEY,
                customer_name TEXT,
                customer_telephone TEXT
            )
        ''')

        # Create the 'customer_addresses' table if it does not exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customer_addresses (
                address_id INTEGER PRIMARY KEY,
                customer_id TEXT,
                address TEXT,
                postcode TEXT,
                FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
            )
        ''')

        # Commit the changes and close the connection
        conn.commit()
        conn.close()

        # print a success message
        print("Database 'pos_database.db' and tables created successfully.")
        
    except Exception as e:
        print(f"Error creating database and tables: {str(e)}")

def empty_product_categories():
    try:
        # Connect to the SQLite database
        conn, cursor = get_database_connection()

        # Delete all records from the "categories" table and get the number of rows affected
        cursor.execute('DELETE FROM category')
        num_categories_deleted = cursor.rowcount

        # Delete all records from the "products" table and get the number of rows affected
        cursor.execute('DELETE FROM products')
        num_products_deleted = cursor.rowcount

        # Commit the changes and close the database connection
        conn.commit()
        conn.close()

        if num_categories_deleted > 0 or num_products_deleted > 0:
            print("Category and Product Tables emptied successfully.")
        else:
            print("No records found to delete.")
    except Exception as e:
        print(f"Error emptying tables: {str(e)}")

def empty_options_items():
    try:
        # Connect to the SQLite database
        conn, cursor = get_database_connection()

        # Delete all records from the "categories" table and get the number of rows affected
        cursor.execute('DELETE FROM options')
        options_deleted = cursor.rowcount

        # Delete all records from the "products" table and get the number of rows affected
        cursor.execute('DELETE FROM option_items')
        items_deleted = cursor.rowcount

         # Delete all records from the "products" table and get the number of rows affected
        cursor.execute('DELETE FROM product_options')
        product_options_deleted = cursor.rowcount

        # Commit the changes and close the database connection
        conn.commit()
        conn.close()

        if options_deleted > 0 or items_deleted > 0 or product_options_deleted > 0:
            print("Option Tables emptied successfully.")
        else:
            print("No records found to delete.")
    except Exception as e:
        print(f"Error emptying tables: {str(e)}")

def get_all_categories():
    try:
        # Connect to the SQLite database
        conn, cursor = get_database_connection()
        # Query the database to get all categories
        cursor.execute('SELECT category_id, category_name FROM category')
        # Fetch all the results as a list of tuples
        categories = cursor.fetchall()
        # Close the database connection
        conn.close()
        # Convert the result to a list of dictionaries
        categories_data = [{'category_id': row[0], 'category_name': row[1]} for row in categories]
        return categories_data
    except Exception as e:
        return [{'error': str(e)}]

def products_by_category(category_id):
    try:
         # Connect to the SQLite database
        conn, cursor = get_database_connection()

        # Query the database to get products for the specified category_id
        cursor.execute('''
            SELECT product_id, product_name, in_price
            FROM products
            WHERE category_id = ?
        ''', (category_id,))
        
        # Fetch all the results
        products = cursor.fetchall()

        # Close the database connection
        conn.close()

        # Convert the result to a list of dictionaries for JSON serialization
        products_data = [{'product_id': row[0], 'product_name': row[1], 'price': row[2]} for row in products]

        return jsonify({'products': products_data})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
def get_products_for_pos(category_id, menu):
    conn, cursor = get_database_connection()
    sql_query = """
        SELECT p.product_id,
               p.product_name,
               CASE
                   WHEN ? = 1 THEN p.out_price
                   WHEN ? = 0 THEN p.in_price
                   ELSE p.in_price
               END AS adjusted_price,
               GROUP_CONCAT(po.option_id) AS option_ids
        FROM products p
        LEFT JOIN product_options po ON p.product_id = po.product_id
        WHERE p.category_id = ?
        GROUP BY p.product_id, p.product_name, adjusted_price
        ORDER BY p.product_name
    """

    cursor.execute(sql_query, (menu, menu, category_id))
    products = cursor.fetchall()
    conn.close()
    return jsonify(products)

def get_options():
    conn, cursor = get_database_connection()
    cursor.execute("SELECT option_id, option_name FROM options")
    options = cursor.fetchall()
    conn.close()
    options_data = [{'option_id': row[0], 'option_name': row[1]} for row in options]
    return jsonify(options_data)

def newCart(cartData):
    try:
        data = cartData
        conn, cursor = get_database_connection()
        # create the customer
        customer = cartData['customer']
        customer_name = customer.get('customerName', '')
        customer_phone = customer.get('customerPhone', '')
        cursor.execute("INSERT INTO customers (customer_name, customer_telephone) VALUES (?, ?)", (customer_name, customer_phone))
        customer_id = cursor.lastrowid

        if 'customerAddress' in customer and customer['customerAddress'] != '' and 'customerPostcode' in customer and customer['customerPostcode'] != '':
            address = customer['customerAddress']
            postcode = customer['customerPostcode']
            cursor.execute('''
            INSERT INTO customer_addresses (customer_id, address, postcode)
            VALUES (?, ?, ?)
        ''', (customer_id, address, postcode))

        cursor.execute('''
            INSERT INTO cart (order_type, order_menu, overall_note, customer_id)
            VALUES (?, ?, ?, ?)
        ''', (data['order_type'], data['order_menu'], data['overall_note'], customer_id))
        conn.commit()
        cart_id = cursor.lastrowid
        conn.close()

        return jsonify({'cart_id': cart_id})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
def get_current_cart_data(cart_id):
    try:
        conn, cursor = get_database_connection()
        cursor.execute('''
            SELECT
                c.cart_id,
                c.order_type,
                c.order_menu,
                c.order_date,
                COUNT(ci.cart_id) AS cart_item_count,
                c.customer_id,
                cu.customer_name,
                cu.customer_telephone,
                CASE WHEN c.order_type = 'delivery'
                    THEN ca.address
                    ELSE NULL
                END AS address,
                CASE WHEN c.order_type = 'delivery'
                    THEN ca.postcode
                    ELSE NULL
                END AS postcode
            FROM cart c
            LEFT JOIN cart_item ci ON c.cart_id = ci.cart_id
            LEFT JOIN customers cu ON c.customer_id = cu.customer_id
            LEFT JOIN customer_addresses ca ON c.customer_id = ca.customer_id AND c.order_type = 'delivery'
            WHERE c.cart_id = ?
            GROUP BY c.cart_id, c.order_type, c.order_menu, c.order_date, cu.customer_name, cu.customer_telephone, ca.address, ca.postcode
            ORDER BY c.order_date
            ''', (cart_id,))
        
        cart_data = cursor.fetchone()  # Retrieve the cart data as a tuple
        if cart_data:
            conn.close()
            return jsonify(cart_data)  # Return the cart data as JSON
        else:
            # Cart not found
            conn.close()
            return jsonify({'error': 'Cart not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def all_carts():
    try:
        conn, cursor = get_database_connection()
        cursor.execute('''
            SELECT
                c.cart_id,
                c.order_type,
                c.order_menu,
                c.order_date,
                c.customer_id,
                COUNT(ci.cart_id) AS cart_item_count
            FROM cart c
            LEFT JOIN cart_item ci ON c.cart_id = ci.cart_id
            GROUP BY c.order_type
            ORDER BY c.order_date
        ''')
        
        results = cursor.fetchall()
        if results:
            conn.close()
            return jsonify(results)
        else:
            # Cart not found
            conn.close()
            return jsonify({'error': 'None found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
def fetch_option_data(option_id, current_method):
    try:
        conn, cursor = get_database_connection()
        cursor.execute('''
            SELECT
                options.*,
                GROUP_CONCAT(
                    'option_item_id: ' || option_items.option_item_id || ', ' ||
                    'option_item_name: ' || option_items.option_item_name || ', ' ||
                    'option_item_price: ' ||
                    CASE
                        WHEN ? = 1 THEN option_items.option_item_out_price
                        ELSE option_items.option_item_in_price
                    END
                ) AS option_items_json
            FROM options
            LEFT JOIN option_items ON options.option_id = option_items.option_id
            WHERE options.option_id = ?
            GROUP BY options.option_id;
        ''', (current_method, option_id))

        # Fetch the result
        result = cursor.fetchone()

        # Close the database connection
        conn.close()

        return result

    except Exception as e:
        # Handle any exceptions or errors here
        print("Error:", str(e))
        return None