from flask import jsonify
import json, sqlite3, os
from . import database

def process_and_insert_products_json_data(add_price):
    try:
        database.empty_product_categories()
        # Get the path to the "uploads" folder within the "pos" blueprint directory
        upload_folder = os.path.join(os.path.dirname(__file__), 'uploads')
        json_file_path = os.path.join(upload_folder, 'products.json')

        # Load the JSON data from the "uploads/products.json" file
        with open(json_file_path, 'r') as json_file:
            data = json.load(json_file)

        # Connect to the SQLite database
        conn, cursor = database.get_database_connection()

        # Initialize counters for inserted rows
        total_inserted = 0

        for category_name, category_data in data.items():
            try:
                category_order = category_data[0]['order']
            except (IndexError, KeyError):
                category_order = 0

            cursor.execute('''
                INSERT INTO category (category_name, category_order)
                VALUES (?, ?)
            ''', (category_name, category_order))
            conn.commit()

            # Get the ID of the last inserted category
            category_id = cursor.lastrowid
            # out_price increase all by 0.50p - add parameter to make dynamic addition to in_price
            out_price_addition = add_price
            for product in category_data:
                if 'vari' not in product:
                    # Insert into the 'products' table for product objects without 'vari'
                    cursor.execute('''
                        INSERT INTO products (category_id, product_name, in_price, out_price, cpn)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (category_id, product['name'], float(product['price']), float(product['price']) + float(out_price_addition), product['cpn']))
                    conn.commit()
                    total_inserted += cursor.rowcount  # Increment the counter
                else:
                    # Insert into the 'products' table for product objects with 'vari'
                    for vari_item in product['vari']:
                        product_name = f"{product['name']} {vari_item['name']}"
                        in_price = float(vari_item['price'])
                        out_price = float(vari_item['price']) + float(out_price_addition)
                        cpn = vari_item['cpn']

                        cursor.execute('''
                            INSERT INTO products (category_id, product_name, in_price, out_price, cpn)
                            VALUES (?, ?, ?, ?, ?)
                        ''', (category_id, product_name, in_price, out_price, cpn))
                        conn.commit()
                        total_inserted += cursor.rowcount  # Increment the counter

        # Close the database connection
        conn.close()
        if total_inserted > 0:
            print("JSON data processed and inserted into the database successfully.")
        else:
            print("No data inserted into the database.")
    except Exception as e:
        print(f"Error processing and inserting JSON data: {str(e)}")

def process_and_insert_options_json_data(add_price):
    try:
        database.empty_options_items()
        # Get the path to the "uploads" folder within the "pos" blueprint directory
        upload_folder = os.path.join(os.path.dirname(__file__), 'uploads')
        json_file_path = os.path.join(upload_folder, 'options.json')

        # Load the JSON data from the specified file
        with open(json_file_path, 'r') as json_file:
            options_json = json.load(json_file)

        # Connect to the SQLite database
        conn, cursor = database.get_database_connection()

        # Initialize counters for inserted rows
        total_inserted = 0

        for option_data in options_json:
            # Insert data into the 'options' table
            option_name = option_data['name']
            option_order = option_data['order']
            option_type = option_data['type']
            required = 1 if option_data['required'] == "required" else 0

            cursor.execute("INSERT INTO options (option_name, option_order, option_type, required) VALUES (?, ?, ?, ?)",
                           (option_name, option_order, option_type, required))
            option_id = cursor.lastrowid  # Get the ID of the inserted option

            # Process and insert option items
            for option_item in option_data['options']:
                option_item_name = option_item['name'].split('+')[0].strip()  # Remove '+' and trailing spaces
                option_item_in_price = float(option_item['price'])
                if option_item_in_price > 0:
                    option_item_out_price = option_item_in_price + float(add_price)
                else:
                    option_item_out_price = option_item_in_price

                cursor.execute("INSERT INTO option_items (option_id, option_item_name, option_item_in_price, option_item_out_price) VALUES (?, ?, ?, ?)",
                               (option_id, option_item_name, option_item_in_price, option_item_out_price))

        conn.commit()
        total_inserted += cursor.rowcount
        conn.close()
        if total_inserted > 0:
                print("Options data processed and inserted into the database successfully.")
        else:
            print("No data inserted into the database.")
    except Exception as e:
        return str(e)

def pos_methods():
    try:
        blueprint_dir = os.path.dirname(os.path.abspath(__file__))
        json_file_path = os.path.join(blueprint_dir, 'pos_settings.json')
        with open(json_file_path, 'r') as file:
            settings = json.load(file)
            pos_methods = settings.get('pos_methods', [])
            
            filtered_pos_methods = [method for method in pos_methods if method.get('on', 0) == 1]
            #print(filtered_pos_methods)
            return jsonify(filtered_pos_methods)
    except FileNotFoundError:
        # Handle the case where the JSON file is not found
        return jsonify([])