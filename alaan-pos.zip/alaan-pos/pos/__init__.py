from flask import Blueprint

# Create the "pos" blueprint
pos_bp = Blueprint('pos', __name__, template_folder='templates')

# Import the routes for the "pos" blueprint
from . import routes