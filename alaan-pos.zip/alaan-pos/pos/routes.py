from flask import render_template, request, jsonify, redirect, url_for
from werkzeug.utils import secure_filename
from . import json_utils, pos_bp, database
import os, json

@pos_bp.route('/pos')
def pos_home():
    database.create_pos_database()
    # Path to the "uploads" folder within the "pos" blueprint directory
    upload_folder = os.path.join(os.path.dirname(__file__), 'uploads')

    # Get the list of files in the "uploads" folder
    uploaded_files = []
    if os.path.exists(upload_folder):
        uploaded_files = [f for f in os.listdir(upload_folder) if os.path.isfile(os.path.join(upload_folder, f))]

    return render_template('pos_index.html', uploaded_files=uploaded_files)

@pos_bp.route('/test')
def test():
    return render_template('test.html')

@pos_bp.route('/pos_start')
def pos_start():
    # Fetch all categories from the database
    categories = database.get_all_categories()
    return render_template('pos.html', categories=categories)

@pos_bp.route('/get_products/<int:category_id>/<int:menu>')
def get_products(category_id,menu):
    return database.get_products_for_pos(category_id, menu)

@pos_bp.route('/process_json')
def process_json():
    return render_template('process_json.html')

@pos_bp.route('/upload_products', methods=['POST'])
def upload_products():
    json_file = request.files['json_file']

    if json_file and json_file.filename.endswith('.json'):
        try:
            # Get the secure filename and the path to the "uploads" folder
            filename = secure_filename(json_file.filename)
            upload_folder = os.path.join(os.path.dirname(__file__), 'uploads')

            # Create the "uploads" folder if it doesn't exist
            if not os.path.exists(upload_folder):
                os.makedirs(upload_folder)

            # Save the JSON file to the "uploads" folder
            file_path = os.path.join(upload_folder, filename)
            # Check if a file with the same name already exists
            if os.path.exists(file_path):
                # If it exists, remove the existing file
                os.remove(file_path)

            # Save the new CSV file to the "uploads" folder
            json_file.save(file_path)

            # Perform your desired JSON processing here
            return redirect(url_for('pos.pos_home'))
        except Exception as e:
            return f"Error processing JSON file: {str(e)}"
    else:
        return "Invalid file. Please upload a JSON file."

@pos_bp.route('/process_json_data/<data_type>/<add_price>', methods=['POST'])
def process_json_data(data_type, add_price):
    try:
        if data_type == "products":
            # Call the function to process and insert products JSON data into the database
            json_utils.process_and_insert_products_json_data(add_price)
        elif data_type == "options":
            # Call the function to process and insert options JSON data into the database
            json_utils.process_and_insert_options_json_data(add_price)
        else:
            return "Invalid data type parameter."

        # Return a JSON response to indicate that the processing is finished
        return jsonify({'finished': True})
    except Exception as e:
        # Handle any errors that may occur during processing
        return jsonify({'error': str(e), 'finished': False}), 500

@pos_bp.route('/show_products')
def show_products():
    categories = database.get_all_categories()
    return render_template('show_products.html', categories=categories)

@pos_bp.route('/get_products_by_category/<category_id>', methods=['GET'])
def get_products_by_category(category_id):
    return database.products_by_category(category_id)

@pos_bp.route('/get_options')
def get_options():
    return database.get_options()

@pos_bp.route('/add_options_to_product', methods=['POST'])
def add_options_to_product():
    conn, cursor = database.get_database_connection()
    try:
        selected_options = request.form.getlist('selectedOptions')
        product_id = request.form.get('productId')

        for option_id in selected_options:
            cursor.execute("INSERT INTO product_options (product_id, option_id) VALUES (?, ?)", (product_id, option_id))
        conn.commit()
        conn.close()

        # Return a success message as a JSON response
        response_data = {'message': 'Options added to the product successfully.'}
        return jsonify(response_data), 200

    except Exception as e:
        # Handle any exceptions that may occur during the database operation
        response_data = {'error': 'An error occurred while adding options to the product.'}
        return jsonify(response_data), 500

@pos_bp.route('/get_pos_methods', methods=['GET'])
def get_pos_methods():
    return json_utils.pos_methods()

@pos_bp.route('/create_cart', methods=['POST'])
def create_cart():
    data = request.get_json()
    return database.newCart(data)

@pos_bp.route('/get_current_cart/<int:cart_id>', methods=['GET'])
def get_current_cart(cart_id):
    return database.get_current_cart_data(cart_id)

@pos_bp.route('/get_all_carts')
def get_all_carts():
    return database.all_carts()

@pos_bp.route('/fetch_options_by_ids', methods=['POST'])
def fetch_options_by_ids():
    try:
        data = request.get_json()
        option_ids = data.get('optionItemIds', [])
        current_method = data.get('currentMethod', 0)  # Default to 0 if not provided

        # Initialize a list to store the results for each option ID
        option_data = []

        for option_id in option_ids:
            result = database.fetch_option_data(option_id, current_method)
            if result:
                option_items_list = []
                result_5 = result[5]
                parts = result_5.split(',')
                current_obj = {}

                for part in parts:
                    key, value = part.strip().split(': ')
                    current_obj[key] = int(value) if key == 'option_item_id' else (float(value) if key == 'option_item_price' else value)
                    
                    if len(current_obj) == 3:
                        option_items_list.append(current_obj)
                        current_obj = {}

                option_data.append({
                    'option_id': result[0],
                    'option_name': result[1],
                    'option_type': result[3],
                    'option_required': result[4],
                    'option_json': option_items_list
                })
        #print(option_data)
        # Return the list of dictionaries as JSON
        return jsonify(option_data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pos_bp.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    item = request.get_json()
    return database.add_item_to_cart(item)

@pos_bp.route('/get_cart_items/<int:cart_id>', methods=['GET'])
def get_cart_items(cart_id):
    return database.get_all_cart_items(cart_id)