import requests, database, config, os, re, json, time, subprocess, threading
from weasyprint import HTML, CSS
from datetime import datetime
from logging_utils import logger, log_error
from io import BytesIO
from PyPDF2 import PdfFileMerger
import win32print

urlSecret = config.SECRET_KEY
urlUsername = config.USERNAME_SIM

def refresh_token():
    if database.any_url_exists():
        urls = database.get_tokens()  # Assuming this gets URLs and tokens as a list of tuples
        if urls:
            tokens = []
            for url, token in urls:
                full_url = "https://" + url + "/app/v1/login.php"

                data = {
                    'secret': urlSecret,
                    'username': urlUsername
                }

                headers = {
                    'Content-Type': 'application/json'
                }

                try:
                    response = requests.post(full_url, json=data, headers=headers)
                    if response.status_code == 200:
                        result = response.json()
                        new_token = result.get('jwt')
                        if new_token:
                            # Update the token in the database
                            database.update_token(url, new_token)
                            tokens.append(new_token)
                except requests.exceptions.RequestException as e:
                    print(f'Error refreshing token for URL {url}: {str(e)}')
                    log_error(f'Error refreshing token for URL {url}: {str(e)}')
            
            if len(tokens) == 1:
                return tokens[0]
            elif len(tokens) > 1:
                return tokens
    return None


def generate_html(order):
    printer_settings = get_printer_settings()

    # Retrieve printer & receipt settings values
    font_size = printer_settings['font_size']
    font_weight = printer_settings['font_weight']
    line_height = printer_settings['line_height']
    footer_text = printer_settings['footer_text']
    header_text = printer_settings['header_text']

    discount = "<h3>Disc: &pound;" + "{:.2f}".format(float(order['discount_value'])) + "</h3>" if float(order['discount_value']) > 0 else ""

    delivery_value = order.get('delivery_value')
    if delivery_value and delivery_value != 'undefined' and delivery_value.replace('.', '', 1).isdigit():
        delivery_fee = "&pound;" + "{:.2f}".format(float(delivery_value)) if float(delivery_value) > 0 else ""
    else:
        delivery_fee = ""
    note = '<h3>Note: ' + order['order_note'] + '</h3><hr>' if order['order_note'] != "" else ""

    order_time = datetime.strptime(order['order_time'], '%Y-%m-%d %H:%M:%S')
    order_for_time = datetime.strptime(order['order_for_time'], '%Y-%m-%d %H:%M:%S')

    items = re.sub(r'(?<!~)<br>', '<br>&nbsp;&nbsp;&nbsp;&nbsp;', order['items'])
    items = re.sub(r'~<br>', '</span><br>', items)
    items = re.sub(r' - ', '<span style="float:right;">£', items)
    items = re.sub(r'~', '</span><br>', items)

    time_formatted = '<h4>' + order_time.strftime("%a %d %b") + '<br>Placed: ' + order_time.strftime("%I:%M%p") + '<br>Due: ' + order_for_time.strftime("%I:%M") + '<br></h4><hr>'
    customer_info = '<h3>' + order['customer_name'] + '<br>' + order['delAdd'] + '<br>' + order['customer_tel'] + '</h3><hr>'
    item_section = '<p style="line-height:'+str(line_height)+';font-weight:'+font_weight+';font-size:'+str(font_size)+'px;">' + items + '</p><hr>'
    item_note = note
    item_count = '<h3>' + order['CNT'] + ' Items</h3><hr>'
    discount_div = '<div style="float:left;">' + discount + '</div>'
    total_div = '<div style="float:right;"><h3>&pound;' + "{:.2f}".format(float(order['order_total'])) + ' ' + order['payment_method'] + '</h3></div>'

    result_html = time_formatted + customer_info + item_section + item_note + item_count + discount_div + total_div

    css_styles = f"""
    body {{
         /* Convert to pixels */
        font-weight: {font_weight};
    }}
    """

    html = f"""
    <html>
    <head>
        <style>
            {css_styles}
        </style>
    </head>
    <body>
    """
    html += f'<p style="text-align:center;">'+order["url"]+'</p>'
    if header_text:
        header_text_html = header_text.replace("\n", "<br>")
        html += f'<p style="text-align:center;">'+header_text_html+'</p>'
    html += '<div class="order">'
    # Generate the content for the order based on order properties
    html += f'<h1>'+order["delivery_collection"]+' '+delivery_fee+'</h1>'
    html += result_html
    html += '</div>'
    # add the footer text if exists
    if footer_text:
        footer_text_html = footer_text.replace("\n", "<br>")
        html += f'<br><br><hr><p style="text-align:center;">'+footer_text_html+'</p>'
    html += '</body></html>'
    return html

def generate_total_html(order):
    #new styles are now passed inside the generate pdf function 31/08
    # Convert JSON string to a list of dictionaries
    order = json.loads(order)
    card = int(order[0].get("CARD") or 0)
    cash = int(order[0].get("CASH") or 0)
    card_total = float(order[0].get("CARDTOTAL") or 0)
    cash_total = float(order[0].get("CASHTOTAL") or 0)
    total_order = card + cash
    total_value = card_total + cash_total

    html_string = ""
    # Add calculated sums to the HTML string
    html_string += f"<p><strong>CARD:</strong><span style='float:right'>{card} orders</span></p>"
    html_string += f"<p><strong>CARD TOTAL:</strong><span style='float:right'>£{card_total}</span></p>"
    html_string += f"<p><strong>CASH:</strong><span style='float:right'>{cash} orders</span></p>"
    html_string += f"<p><strong>CASH TOTAL:</strong><span style='float:right'>£{cash_total}</span></p>"
    html_string += f"<hr>"
    html_string += f"<p><strong>TOTAL ORDERS:</strong><span style='float:right'>{total_order} orders</span></p>"
    html_string += f"<p><strong>GRAND TOTAL:</strong><span style='float:right'>£{total_value:.2f}</span></p>"

    return html_string

def generate_kitchen_html(order):
    printer_settings = get_printer_settings()

    # Retrieve printer & receipt settings values
    font_size = printer_settings['font_size']
    font_weight = printer_settings['font_weight']
    line_height = printer_settings['line_height']

    note = '<h3>Note: ' + order['order_note'] + '</h3><hr>' if order['order_note'] != "" else ""

    order_time = datetime.strptime(order['order_time'], '%Y-%m-%d %H:%M:%S')
    order_for_time = datetime.strptime(order['order_for_time'], '%Y-%m-%d %H:%M:%S')

    items = re.sub(r'(?<!~)<br>', '<br>&nbsp;&nbsp;&nbsp;&nbsp;', order['items'])
    items = re.sub(r'~<br>', '</span><br>', items)
    items = re.sub(r' - ', '<span style="float:right;">£', items)
    items = re.sub(r'~', '</span><br>', items)

    time_formatted = '<h4>' + order_time.strftime("%a %d %b") + '<br>Placed: ' + order_time.strftime("%I:%M%p") + '<br>Due: ' + order_for_time.strftime("%I:%M") + '<br></h4><hr>'
    customer_info = '<h3>' + order['customer_name'] + '<br>' + order['delAdd'] + '<br>' + order['customer_tel'] + '</h3><hr>'
    item_section = '<p style="line-height:'+str(line_height)+';font-weight:'+font_weight+';font-size:'+str(font_size)+'px;">' + items + '</p><hr>'
    item_note = note
    item_count = '<h3>' + order['CNT'] + ' Items</h3><hr>'
    total_div = '<div style="float:right;"><h3>&pound;' + "{:.2f}".format(float(order['order_total'])) + ' ' + order['payment_method'] + '</h3></div>'

    result_html = time_formatted + customer_info + item_section + item_note + item_count + total_div

    css_styles = f"""
    body {{
         /* Convert to pixels */
        font-weight: {font_weight};
    }}
    """

    html = f"""
    <html>
    <head>
        <style>
            {css_styles}
        </style>
    </head>
    <body>
    """

    html += '<div class="order">'
    # Generate the content for the order based on order properties
    html += f'<h1>'+order["delivery_collection"]+'</h1>'
    html += result_html
    html += '</div>'
    
    html += '</body></html>'
    return html

# Define a function to convert HTML to PDF
def convert_html_to_pdf(html_content, pdf_folder_path, file_name):
    # Define the initial page size in millimeters (80mm width)
    page_width_mm = 80
    page_height_mm = 350  # 297 = A4 length in mm

        # Convert HTML to PDF with WeasyPrint
    html = HTML(string=html_content)
    css = CSS(string='@page { size: %smm %smm; margin: 0; }' % (page_width_mm, page_height_mm))

    # Create a PDF document
    pdf_data = BytesIO()
    pdf_document = html.write_pdf(target=pdf_data, stylesheets=[css])

    # Check if the content exceeds the initial page height
    if pdf_document:
        pdf_data.seek(0)  # Reset the buffer position

        # Split the content into pages if it exceeds the initial page height
        pdf_merger = PdfFileMerger()
        pdf_merger.append(pdf_data)

        if pdf_merger.pages > 1:
            pdf_data = BytesIO()  # Reset the buffer
            pdf_merger.write(pdf_data)

    # Save the final PDF to the specified file path
    pdf_file_path = os.path.join(pdf_folder_path, file_name)
    with open(pdf_file_path, 'wb') as f:
        f.write(pdf_data.getvalue())

    return pdf_file_path

def generate_pdf(order):
    # check if kitchen print is on
    printer_settings = get_printer_settings()
    kitchen_print = printer_settings["kitchen_print"]
    num_copies = printer_settings["copies"]
    # Generate the HTML content for the order
    if "CARD" in order:
        html_content = generate_total_html(order)
    else:
        html_content = generate_html(order)
    
    # Define the output folder path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    pdf_folder_path = os.path.join(script_dir, 'print-files')
    os.makedirs(pdf_folder_path, exist_ok=True)  # Create the folder if it doesn't exist

    # Define the PDF file path based on your condition
    if "CARD" in order:
        today_date = datetime.now().strftime("%d_%m_%y")
        pdf_file_path = os.path.join(pdf_folder_path, f"report_{today_date}.pdf")
    else:
        pdf_file_path = os.path.join(pdf_folder_path, f"order_{order['order_id']}.pdf")
        
    # Convert HTML to PDF and save it
    converted_pdf_path = convert_html_to_pdf(html_content, pdf_folder_path, os.path.basename(pdf_file_path))
    print_pdf(converted_pdf_path, num_copies)

    # Check if kitchen_print is True and generate a kitchen PDF
    if kitchen_print:
        kitchen_html_content = generate_kitchen_html(order)
        kitchen_pdf_file_path = os.path.join(pdf_folder_path, f"kitchen_order_{order['order_id']}.pdf")

        # Convert kitchen HTML to PDF and save it
        convert_html_to_pdf(kitchen_html_content, pdf_folder_path, os.path.basename(kitchen_pdf_file_path))
        print_pdf(kitchen_pdf_file_path, 1)

def print_pdf(pdf_file_path, copies):
    printer_name = win32print.GetDefaultPrinter()

    def run_subprocess():
        # Open a handle to the printer
        printer_handle = win32print.OpenPrinter(printer_name)

        try:
            # Get printer status
            printer_info = win32print.GetPrinter(printer_handle, 2)
            if printer_info['Status'] == 0:
                try:
                # Get the path to the current user's AppData\Local folder
                    local_appdata_path = os.getenv('LOCALAPPDATA')
                    # Specify the subfolder and executable name
                    sumatra_pdf_path = os.path.join(local_appdata_path, 'SumatraPDF', 'SumatraPDF.exe')
                    
                    for _ in range(copies):
                        # Use SumatraPDF to print the PDF to the specified printer
                        subprocess.run([sumatra_pdf_path, '-print-to', printer_name, pdf_file_path])
                except Exception as e:
                    print(f"Error printing PDF: {str(e)}")
            else:
                print(f"Printer {printer_name} is not ready.")
        finally:
            # Close the printer handle when done
            win32print.ClosePrinter(printer_handle)

    # Create and start a new thread for the subprocess
    subprocess_thread = threading.Thread(target=run_subprocess)
    subprocess_thread.start()


def delete_print_id_file():
    file_path = "printed_order_ids.json"
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"File '{file_path}' has been deleted.")
    else:
        print(f"File '{file_path}' does not exist.")

def delete_all_print_files():
    folder_path = "print-files"
    if not os.path.exists(folder_path):
        print(f"Folder '{folder_path}' does not exist.")
        return

    pdf_files = [f for f in os.listdir(folder_path) if f.lower().endswith(".pdf")]
    
    if not pdf_files:
        #print(f"No PDF files found in '{folder_path}'.")
        return

    for pdf_file in pdf_files:
        file_path = os.path.join(folder_path, pdf_file)
        os.remove(file_path)
        print(f"Deleted '{pdf_file}'.")

def clear_print_id_file():
    file_path = "printed_order_ids.json"
    if os.path.exists(file_path):
        with open(file_path, "w") as json_file:
            json.dump([], json_file)  # Write an empty array to the file
            os.fsync(json_file.fileno())
        #print(f"Contents of file '{file_path}' have been cleared.")
    else:
        print(f"File '{file_path}' does not exist.")

    # Ensure the file is properly closed
    # try:
    #     os.fsync(json_file.fileno())
    # except Exception as e:
    #     print(f"Error while flushing file: {str(e)}")


def reservation_prints():
    if database.any_url_exists():
        SLEEP_DURATION = 30  # 1800 = 30 minutes in seconds
        checkForUrl = True

        def run_reservation_prints():
            nonlocal checkForUrl
            while checkForUrl:
                try:
                    # Fetch URLs and tokens from the database
                    urls_tokens = database.get_tokens()  # Assuming this gets URLs and tokens as a list of tuples
                    if urls_tokens:
                        for url, token in urls_tokens:
                            headers = {
                                'Authorization': f'Bearer {token}',
                                'Content-Type': 'application/json'
                            }
                            full_url = "https://" + url + "/app/v1/reservations.php"
                            print(full_url)
                            response = requests.post(full_url, headers=headers)
                            if response.status_code == 200:
                                try:
                                    json_data = response
                                    print(f"URL {url} exists, making request...")
                                    print(json_data)
                                # Process the JSON data here
                                except json.JSONDecodeError as json_error:
                                    print(f"JSON decode error for URL {url}: {json_error}")
                        
                            else:
                                print(f"HTTP request for URL {url} failed with status code:", response.status_code)
                                checkForUrl = False
                    else:
                        print("No URLs and tokens found in the database")

                    # Sleep for 30 minutes (1800 seconds)
                    time.sleep(SLEEP_DURATION)

                except requests.exceptions.RequestException as e:
                    print("URL not accessible: %s" % e)
                    checkForUrl = False

        # Create and start the thread for reservation checks
        reservation_thread = threading.Thread(target=run_reservation_prints)
        reservation_thread.daemon = True
        reservation_thread.start()

def get_printer_settings():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_path = os.path.join(script_dir, 'printer_settings.json')
    
    with open(settings_path, 'r') as settings_file:
        printer_settings = json.load(settings_file)

    return printer_settings
