from flaskwebgui import FlaskUI
from flask import Flask, render_template, render_template_string, request, jsonify, redirect, url_for
from flask_cors import CORS, cross_origin
import database, requests, json, os
import config
import helpers
from logging_utils import logger, log_error
from pos import pos_bp  # Import the "pos" blueprint

app = Flask(__name__)
cors = CORS(app)

# Register the "pos" blueprint
app.register_blueprint(pos_bp)

printed_order_ids = []
json_file_path = "printed_order_ids.json"

if os.path.exists(json_file_path) and os.path.getsize(json_file_path) > 0:
    with open(json_file_path, "r") as json_file:
        printed_order_ids = json.load(json_file)

if not os.path.exists(json_file_path):
    with open(json_file_path, "w") as json_file:
        json.dump([], json_file)

urlSecret = config.SECRET_KEY
urlUsername = config.USERNAME_SIM

@app.route('/')
def home():
    database.create_tables()
    tokens = helpers.refresh_token()  # Get a list of tokens
    if not database.any_url_exists() or not tokens:
        return render_template('home.html')
    else:
        return render_template('orders.html', tokens=tokens)

#for first login and adding new urls
@app.route('/token')
def token():
    url = request.args.get('url')
    
    fullUrl = "https://"+url+"/app/v1/login.php"

    data = {
        'secret': urlSecret,
        'username': urlUsername
    }

    headers = {
        'Content-Type': 'application/json'
    }

    try:
        response = requests.post(fullUrl, json=data, headers=headers)
       
        if response.status_code == 200:
            result = response.json()  # Parse JSON response
            jwt = result.get('jwt')    # Get jwt from parsed response
            
            if jwt:
                database.create_tables()  # Create the table if it doesn't exist
                database.insert_token(url, jwt)
                return jsonify({'success': True, 'message': 'URL added successfully'})
            else:
                result_message = 'JWT not found in the response'
        else:
            result = {'message': f'POST request failed with status code: {response.status_code}'}
            result_message = result['message']
            logger.info("Initial Token request")
            log_error(f'POST request failed with status code: {response.status_code}')
            
    except requests.exceptions.RequestException as e:
        result = {'message': f'Error: {str(e)}'}
        result_message = result['message']
        logger.info("Initial Token final exception")
        log_error(f'Error: {str(e)}')
    
    return jsonify({'message': result_message})

@app.route('/get_orders', methods=['POST'])
def get_orders():
    if database.any_url_exists():
        urls = database.get_tokens()  # Assuming this gets URLs and tokens as a list of tuples
        if urls:
            results = []
            for url, token in urls:
                data = {}
                headers = {
                    'Authorization': f'Bearer {token}',
                    'Content-Type': 'application/json'
                }
                full_url = "https://" + url + "/app/v1/orders.php"
                try:
                    response = requests.post(full_url, json=data, headers=headers)
                    if response.status_code == 200:
                        result = response.json()
                        for order in result:
                            order['url'] = url  # Add the URL to each order dictionary
                            # Get the order ID
                            order_id = order.get('order_id')

                            # Check if the order ID has been printed before
                            if order_id and order_id not in printed_order_ids:
                                # Generate a PDF receipt using weasyprint
                                helpers.generate_pdf(order)
                                
                                # Add the order ID to the printed_order_ids list
                                printed_order_ids.append(order_id)

                        with open(json_file_path, "w") as json_file:
                            json.dump(printed_order_ids, json_file)
                        results.extend(result)
                        if len(results) > 1:  # Check if there are more than one array merged
                            # Sort results by order_time in descending order
                            results = sorted(results, key=lambda x: x.get('order_time'), reverse=True)

                    else:
                        return jsonify(response.json())
                except requests.exceptions.RequestException as e:
                    results.append({'error': f'Error: {str(e)}'})
                    logger.info("Get orders exception")
                    log_error(f'Error: {str(e)}')

            if len(results) == 0:
                helpers.delete_all_print_files()
                helpers.clear_print_id_file()
                return jsonify(results)
            else:
                return jsonify(results)
        else:
            logger.info("No URLs available in the database")
            return jsonify({'message': 'No URLs available in the database'})
    else:
        logger.info("No URLs available in the database")
        return jsonify({'message': 'No URLs available in the database'})



@app.route('/refresh_token', methods=['GET'])
def refresh_token_route():
    token = helpers.refresh_token()  # Call the refresh_token function here
    #print(token)
    if token:
        return jsonify({'token': token})
    else:
        logger.info("Unable to refresh token")
        return jsonify({'error': 'Unable to refresh token'})

@app.route('/update_order/<id>/<status>/<orderFor>/<siteUrl>', methods=['POST'])
def update_order(id, status, orderFor, siteUrl):

    url = siteUrl  # Assuming you want to use the first URL
    fullUrl = "https://"+url+"/app/v1/update.php"
    
    # Construct the JSON data
    data = {
        "id": id,
        "status": status,
        "orderFor": orderFor
    }
    
    # Set headers
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        # Make the HTTP POST request
        response = requests.post(fullUrl, json=data, headers=headers)
        
        if response.status_code == 200:
            return jsonify({"message": "Order updated successfully"})
        else:
            return jsonify({"message": f"Failed to update order. Status code: {response.status_code}"})
    except requests.exceptions.RequestException as e:
        logger.info("Update orders exception")
        log_error(f'Error: {str(e)}')
        return jsonify({"message": f"Error: {str(e)}"})

@app.route('/manual_print', methods=['POST'])
def manuel_print():
    order_data = request.json
    helpers.generate_pdf(order_data)
    response_data = {"message": "Data received successfully"}
    return jsonify(response_data)

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/printer_settings')
def printer_settings():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_path = os.path.join(script_dir, 'printer_settings.json')
    
    with open(settings_path, 'r') as settings_file:
        printer_settings = json.load(settings_file)

    return render_template('printer-settings.html', printer_settings=printer_settings)

@app.route('/save_printer_settings', methods=['POST'])
def save_printer_settings():
    # Get form data
    paper_width = request.form.get('paper_width')
    line_height = float(request.form.get('line_height'))
    font_size = request.form.get('font_size')
    font_weight = request.form.get('font_weight')
    copies = request.form.get('copies')
    footer = request.form.get('footer_text')
    if footer is not None:
        footer = footer.replace("\r\n", "\n")
    header = request.form.get('header_text')
    if header is not None:
        header = header.replace("\r\n", "\n")
    kitchen_print = request.form.get('kitchen_print')
    reservation_print = request.form.get('reservation_print')

    # Construct settings dictionary
    settings = {
        "paper_width": paper_width,
        "paper_height": "auto",
        "margin_size": 0,
        "padding_size": 0,
        "line_height": float(line_height),
        "font_size": int(font_size),
        "font_weight": font_weight,
        "copies": int(copies),
        "footer_text": footer,
        "header_text": header,
        "kitchen_print": kitchen_print,
        "reservation_print": reservation_print
    }

    # Save settings to JSON file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_path = os.path.join(script_dir, 'printer_settings.json')
    
    with open(settings_path, 'w') as settings_file:
        json.dump(settings, settings_file, indent=4)

    return redirect(url_for('printer_settings'))

@app.route('/get_totals')
def get_totals():
    if database.any_url_exists():
        urls = database.get_tokens()  # Assuming this gets URLs and tokens as a list of tuples
        if urls:
            url = urls[0][0]  # first URL
            token = urls[0][1] # first url's token
            data = {}
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            fullUrl = "https://" + url + "/app/v1/daily.php"
            try:
                response = requests.post(fullUrl, json=data, headers=headers)
                if response.status_code == 200:
                    result = response.json()
                    return render_template('count.html', result=result, url=url)
                else:
                    return jsonify(response.json())
            except requests.exceptions.RequestException as e:
                logger.info("Get totals exception")
                log_error(f'Error: {str(e)}')
                return jsonify({'message': f'Error: {str(e)}'})
        else:
            return jsonify({'message': 'No URLs available in the database'})
    else:
        return jsonify({'message': 'No URLs available in the database'})
    
@app.route("/print_total", methods=["POST"])
def print_total():
    data = request.json  # Get the JSON data from the request

    result = data.get("result")  # Get the "result" property from the JSON data
    if result is not None:
        #print(result)
        helpers.generate_pdf(result)
        return jsonify({"message": "Print request received"})
    else:
        return jsonify({"error": "Invalid data format"})
    
@app.route('/display_urls')
def display_urls():
    urls_data = database.get_urls()
    #print(urls_data)
    return render_template('urls.html', urls_data=urls_data)

@app.route('/delete_url', methods=['DELETE'])
def delete_url():
    url_id = request.args.get('id')
    if url_id:
        database.delete_url(url_id)
        return jsonify({'success': True, 'message': 'URL deleted successfully'})
    else:
        return jsonify({'success': False, 'message': 'URL ID not provided'})

@app.route('/expired')
def expired():
    return render_template('expired.html')

@app.route('/completed')
def completed():
    return render_template('completed.html')

if __name__ == '__main__':

    #helpers.reservation_prints()
    app.run(debug=True)
    #FlaskUI(app=app, server="flask").run()