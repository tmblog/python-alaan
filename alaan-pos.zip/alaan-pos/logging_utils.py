import os
import logging

# Create the logs folder if it doesn't exist
if not os.path.exists("logs"):
    os.makedirs("logs")

# Configure the logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename="logs/app.log.txt",  # Specify the log file path
    filemode="a"
)

# Disable automatic logging by setting the logging level to a higher level
logging.getLogger().setLevel(logging.WARNING)
# Disable Flask and Werkzeug's internal logging
#app.logger.setLevel(logging.WARNING)  # Set Flask logger level to WARNING
werkzeug_logger = logging.getLogger('werkzeug')
werkzeug_logger.setLevel(logging.WARNING)  # Set Werkzeug logger level to WARNING

# Create and configure the logger instance
logger = logging.getLogger(__name__)

# Define additional helper functions if needed
# For example:
def log_error(message):
    logger.error(message)
