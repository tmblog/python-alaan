import sqlite3

def create_tables():
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tokens (
            id INTEGER PRIMARY KEY,
            url TEXT,
            token TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_token(url, token):
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO tokens (url, token) VALUES (?, ?)', (url, token))
    conn.commit()
    conn.close()

def update_token(url, new_token):
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE tokens SET token = ? WHERE url = ?', (new_token, url))
    conn.commit()
    conn.close()

def get_tokens():
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT url, token FROM tokens')
    tokens = cursor.fetchall()
    conn.close()
    return tokens

def any_url_exists():
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT EXISTS (SELECT 1 FROM tokens LIMIT 1)')
    exists = cursor.fetchone()[0]  # Extracts the value from the tuple
    conn.close()
    return exists

def get_urls():
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, url FROM tokens')
    tokens = cursor.fetchall()
    conn.close()
    return tokens

def delete_url(url_id):
    # Connect to the database and delete the URL by ID
    conn = sqlite3.connect('data.db')  # Replace with your database connection
    cursor = conn.cursor()
    cursor.execute('DELETE FROM tokens WHERE id = ?', (url_id,))
    conn.commit()
    conn.close()