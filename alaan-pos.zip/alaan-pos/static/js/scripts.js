function showRefreshButton() {
    window.location.replace('expired');
}

// Hide the button when the token is refreshed
function hideRefreshButton() {
    window.location.replace('/');
}

function manualRefreshToken() {
    console.log('Manually refreshing token...');
    hideRefreshButton();  // Hide the button before refresh
    refreshTokenAndFetchData();
}

function generateButton(status, id, newTime, url) {
    let buttonClass = "";
    let buttonDisabled = "";
    let buttonLabel = "";
    newStatus = ""
    //set new processes to pass to update
    //how to make timeUpdate status? Call updateOrder function direct from other button with time.
    if (status === "processing") {
        buttonClass = "btn-primary";
        buttonLabel = "Accept";
        newStatus = "accepted"
        onclickFunction = "acceptOrder";
        playAudio();
    } else if (status === "accepted") {
        buttonClass = "btn-warning";
        buttonLabel = "Progress";
        newStatus = "progress"
        onclickFunction = "progressOrder";
    } else if (status === "completed") {
        buttonClass = "btn-success";
        buttonLabel = "Completed";
        onclickFunction = "null";
        buttonDisabled = "disabled";
    } else {
        buttonClass = "btn-info";
        buttonLabel = "Error";
        onclickFunction = "null";
        buttonDisabled = "disabled";
    }

    const onclickAttr = `onclick="${onclickFunction}('${id}', '${newStatus}', '${newTime}', '${url}')"`

    return `<button class="btn btn-lg mt-3 rounded-0 ${buttonClass}" ${buttonDisabled} ${onclickAttr}>${buttonLabel}</button>`;
}

function playAudio() {
    const audioElement = document.getElementById("autoplayAudio");

    // Check if the audio element exists
    if (audioElement || audioElement.paused) {
        audioElement.loop = true;
        // Play the audio
        audioElement.play().catch(error => {
            console.error('Error playing audio:', error);
        });
    } else {
        console.error('Audio element not found.');
    }
}


function stopAudio() {
    const audioElement = document.getElementById("autoplayAudio");

    // Check if the audio element exists and is playing
    if (audioElement && !audioElement.paused) {
        audioElement.pause();
        audioElement.currentTime = 0; // Reset playback position
    }
}

function acceptOrder(id, status, orderFor, siteUrl) {
    const url = `/update_order/${id}/${status}/${orderFor}/${siteUrl}`;
    
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => response.json())
    .then(data => {
      console.log(data.message);
      if(data.message) {
        fetchData();
        stopAudio();
      }
    })
    .catch(error => {
      console.error('Error updating order:', error);
    });
    console.log("Accepted order:", id, status, orderFor);
  }

function progressOrder(order_id, status="", for_time, siteUrl) {
    var myModal = new bootstrap.Modal(document.getElementById('progressOrderModal'));

    // Clear existing options from the dropdown
    var timeDropdown = document.getElementById('timeDropdown');
    timeDropdown.innerHTML = '';

    // Parse the given time using Moment.js
    var parsedTime = moment(for_time, 'HH:mm');

    // Calculate the nearest quarter-hour
    var nearestQuarterHour = Math.ceil(parsedTime.minute() / 15) * 15;
    parsedTime.minute(nearestQuarterHour);

    // Create dropdown options with 15-minute intervals
    for (var i = 0; i < 8; i++) {
        var optionTime = parsedTime.format('hh:mm');
        var option = document.createElement('option');
        option.value = optionTime;
        option.text = optionTime;
        timeDropdown.appendChild(option);

        // Increment by 15 minutes
        parsedTime.add(15, 'minutes');

        var orderIdInput = document.getElementById('orderIdInput');
        orderIdInput.value = order_id; // Set the id value

        var orderUrlInput = document.getElementById('orderUrlInput');
        orderUrlInput.value = siteUrl; // Set the url value
    }

    myModal.show();
}

function getTimeFromDropdown() {
    var timeDropdown = document.getElementById('timeDropdown');
    var selectedTime = timeDropdown.value;
    return selectedTime;
}

function acceptOrderFromModal() {
    var id = document.getElementById('orderIdInput').value;
    var selectedTime = getTimeFromDropdown();
    var siteUrl = document.getElementById('orderUrlInput').value;

    // Call the acceptOrder() function with the necessary parameters
    acceptOrder(id, 'timeUpdate', selectedTime, siteUrl);
    // Get the modal instance
    var modalElement = document.getElementById('progressOrderModal');
    var modalInstance = bootstrap.Modal.getInstance(modalElement);

    // Close the modal
    modalInstance.hide();
}

function completeOrderFromModal() {
    var id = document.getElementById('orderIdInput').value;
    var selectedTime = getTimeFromDropdown();
    var siteUrl = document.getElementById('orderUrlInput').value;
    fetchData();
    // Call the acceptOrder() function with the necessary parameters
    acceptOrder(id, 'completed', selectedTime, siteUrl);
    // Get the modal instance
    var modalElement = document.getElementById('progressOrderModal');
    var modalInstance = bootstrap.Modal.getInstance(modalElement);

    // Close the modal
    modalInstance.hide();
}

function printOrderManual(button) {
    const orderData = {
        "order_id": button.getAttribute("data-order_id"),
        "order_time": button.getAttribute("data-time"),
        "delivery_collection": button.getAttribute("data-delivery"),
        "customer_name": button.getAttribute("data-name"),
        "customer_tel": button.getAttribute("data-tel"),
        "order_for_time": button.getAttribute("data-for"),
        "delAdd": button.getAttribute("data-address"),
        "items": button.getAttribute("data-items"),
        "order_total": button.getAttribute("data-total"),
        "discount_value": button.getAttribute("data-discount"),
        "payment_method": button.getAttribute("data-payment"),
        "order_note": button.getAttribute("data-note"),
        "delivery_value": button.getAttribute("data-delivery_value"),
        "CNT": button.getAttribute("data-count"),
        "url": button.getAttribute("data-url")
    };

    //console.log(orderData);
    
    // Send the orderData to a Flask route using fetch or axios
    fetch('/manual_print', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData),
    })
        .then(response => response.json())
        .then(data => {
            console.log('Response from Flask:', data);
            // Handle the response from the Flask route if needed
        })
        .catch(error => {
            console.error('Error sending data:', error);
        });
}